<?php
$mysqliConect = new mysqli ('localhost', 'root', 'registro');
if (!$mysqliConect) {
    echo "error al conectar la base de datos";


}
 $nombre=$POST['nombre'];
 $apellido=$POST['apellido'];
 $dni=$POST['dni'];
 $rol=$POST['rol'];
 
