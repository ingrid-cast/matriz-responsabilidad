<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Iniciar sesión</title>
</head>

<body>

    <div class="container">
        <form action="loginempleado.php" method="post">
            <label for="usuario">Usuario:</label>
            <input type="text" id="usuario" name="usuario" required>

            <label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" required>

            <button type="submit" class="btn btn-primary">Iniciar sesión</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <script>
    <?php
// Incluir el archivo de conexión
include("conexion.php");

// Obtener la conexión
$con = conectar();

// Verificar si la conexión es exitosa
if (!$con) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Obtener los datos del formulario
$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];
// Después de verificar las credenciales
$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

// Consulta SQL para verificar el usuario y la contraseña
$sql = "SELECT * FROM empleados WHERE usuario='$usuario' AND contrasena='$contrasena'";
$result = mysqli_query($con, $sql);

// Verificar si se encontró un usuario
if (mysqli_num_rows($result) > 0) {
    // Inicio de sesión exitoso
    $filaUsuario = mysqli_fetch_assoc($result);
    $nombreEmpleado = $filaUsuario['nombre'];

    // Iniciar sesión y almacenar datos en variables de sesión
    session_start();
    $_SESSION['nombreUsuario'] = $usuario;
    $_SESSION['nombreEmpleado'] = $nombreEmpleado;

    echo "Inicio de sesión exitoso. ¡Bienvenido, $nombreEmpleado!";

    // Redirigir al usuario a indexempleado.php
    header("Location: indexempleado.php");
    exit(); // Asegura que el script se detenga después de la redirección
} else {
    echo "Usuario o contraseña incorrectos.";
}

// Cerrar la conexión
mysqli_close($con);
?>
</script>
    <script src="script.js"></script>
</body>

</html>
