<?php
include("conexion.php");
$con = conectar();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id']) && isset($_POST['actividad'])) {
    $id = $_POST['id'];
    $actividad = $_POST['actividad'];

    $query = "UPDATE actividades SET actividad = '$actividad' WHERE id_actividad = $id";

    if (mysqli_query($con, $query)) {
        echo "Registro actualizado correctamente";
    } else {
        echo "Error al actualizar el registro: " . mysqli_error($con);
    }
}
?>
