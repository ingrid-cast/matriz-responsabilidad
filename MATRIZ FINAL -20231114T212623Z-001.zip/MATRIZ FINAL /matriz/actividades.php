<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Tabla con Datos</title>
</head>

<body>

    <div class="container">
        <form action="guardar_actividad.php" method="POST">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="index.php">Tabla</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarText">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link" href="empleados.php">Empleados</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="proyectos.php">Proyectos</a>
                            </li>
                            <li class="nav-item">
                                 <a class="nav-link" href="actividades.php">Actividades</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="estados.php">Asignacion de Estados</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <h1>Actividades</h1>
            <div class="row justify-content-md-center">
                <form id="data-form" class=" col-sm-4">

                    <label for="Actividad">Nombre Actividad:</label>
                    <input class="form-control" type="text" id="actividad" name="actividad" required>

                    <button type="submit" formmethod="post" formaction="guardar_actividad.php" id="submit-button">Agregar a la Tabla</button>
                </form>
            </div>

            <div>
                <?php
                include("conexion.php");
                $con = conectar();
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $actividad = $_POST['actvidad'];
                    mysqli_query($con, "INSERT INTO `actividades` (`actividad`) VALUES ('$actividad');");
                }

                // Obtener datos de la base de datos
                $resultado = mysqli_query($con, "SELECT * FROM actividades");

                // Mostrar datos en la tabla
                echo '<table id="data-table2" class="table">
                <thead>
                    <tr>
                        <th>Actividad</th>
                    </tr>
                </thead>
                <tbody>';

                while ($fila = mysqli_fetch_array($resultado)) {
                    echo '<tr>';
                    echo '<td><span id="actividad_'.$fila['id_actividad'].'">'.$fila['actividad'].'</span></td>';
                    echo '<td>
                <button class="btn btn-primary" onclick="habilitarEdicion('.$fila['id_actividad'].')">Editar</button>
                <button class="btn btn-danger" onclick="borrarFila('.$fila['id_actividad'].')">Borrar</button>
                </td>';
                echo '</tr>';

                }

                echo '</tbody>
                </table>';

                desconectar($con);
                ?>
            </div>

            <script>
            function borrarFila(id_actividad) {
                if (confirm('¿Estás seguro de que quieres borrar esta actividad?')) {
                    fetch(`borrar_actividad.php?id_actividad=${id_actividad}`)
                        .then(response => {
                            location.reload();
                        })
                        .catch(error => console.error('Error al borrar actividad:', error));
                }
            }
            </script>
            <script>
            function habilitarEdicion(id) {
            var actividadSpan = document.getElementById('actividad_' + id);

            var actividadValor = actividadSpan.innerText;
           

            actividadSpan.innerHTML = '<input type="text" value="' + actividadValor + '" id="actividad_input_' + id + '">';
            var editarButton = document.querySelector('button[onclick="habilitarEdicion(' + id + ')"]');
            editarButton.setAttribute('onclick', 'editarFila(' + id + ')');
            editarButton.innerText = 'Guardar';
        }

            function editarFila(id) {
            var actividad = document.getElementById('actividad_input_' + id).value;

            var data = new URLSearchParams();
            data.append('id', id);
            data.append('actividad', actividad);

            fetch('editar_actividad.php', {
            method: 'POST',
            body: data
            })
            .then(response => {
            location.reload();
            })
            .catch(error => console.error('Error al editar actividad:', error));
        }
    </script>


        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <script src="script.js"></script>
</body>

</html>
