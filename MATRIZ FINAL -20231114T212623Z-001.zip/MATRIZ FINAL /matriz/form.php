<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form id="data-form" class=" col-sm-4">

<label for="proyectos">Proyecto:</label>
<select class="form-select" name="proyectos" id="proyectos">
<option selected="Selecione una opcion">Selecione una opcion
<?php
    include ("conexion.php");
    $con=conectar();
    $getProyectos1="SELECT * FROM proyectos ORDER BY id_proyecto";
    $getProyectos2=mysqli_query($con,$getProyectos1);
        while($row =mysqli_fetch_array($getProyectos2))
        {
        $id_proyecto=$row['id_proyecto'];
        $proyectos=$row['proyecto'];
        $fecha_Inicio=$row['fecha_Inicio'];
        $estadoproyecto=$row['estadoproyecto'];
        
        ?>
        <option value="<?php echo $proyectos;?>"><?php echo $proyectos?> </option>
        <?php
        }
        ?>
        </option>

</select>

<label for="actividades">Actividad:</label>
<select class="form-select" name="actividades" id="actividades">
<option selected="Selecione una opcion">Selecione una opcion
<?php

    $getActividades1="SELECT * FROM actividades ORDER BY id_actividad";
    $getActividades2=mysqli_query($con,$getActividades1);
      while($row =mysqli_fetch_array($getActividades2))
      {
        $id_actividad=$row['id_actividad'];
        $actividad=$row['actividad'];
      
      ?>
      <option value="<?php echo $actividad;?>"><?php echo $actividad?> </option>
      <?php
      }
      ?>
      </option>

</select>

<label for="empleado">Empleado:</label>
    <select class="form-select" name="nombre" id="nombre">
    <option selected="Selecione una opcion">Selecione una opcion
    <?php


    $getEmpleados1="SELECT * FROM empleados ORDER BY id_empleado";
    $getEmpleados2=mysqli_query($con,$getEmpleados1);
      while($row =mysqli_fetch_array($getEmpleados2))
      {
        $id_empleado=$row['id_empleado'];
        $nombre=$row['nombre'];
        $apellido=$row['apellido'];
        $dni=$row['dni'];
      ?>
      <option value="<?php echo $nombre;?>"><?php echo $nombre?> </option>
      <?php
      }
      ?>
   </option>
  </select>



<button type="submit" formmethod="post" formaction="guardartabla.php" id="submit-button">Agregar a la Tabla</button>
</form></div>
</body>
</html>