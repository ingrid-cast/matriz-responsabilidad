<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Tabla con Datos</title>
</head>

<body>
<body>
  <form action="" method="POST">
  <!--Bara de Navegacion-->
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
              <a class="navbar-brand" href="index.php">Tabla</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link" href="empleados.php">Empleados</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="proyectos.php">Proyectos</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="actividades.php">Actividades</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="estados.php">Asignacion de Estados</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
          <h1>Estados</h1>
        <div class="row justify-content-md-center">

            <form id="data-form" class=" col-sm-4">

            <h1>Asignacion de Estados del Proyecto</h1>
            <div> 
            <table id="data-table2">
            <thead>
                <tr>
                    <th>Proyecto</th>
                    <th>Estado</th>
                    <th>Actividad</th>
                    <th>Estado</th>
         
                </tr>
            </thead>
            <tbody>
                <?php
                include("conexion.php");
                $con=conectar();
                $result = mysqli_query($con, "SELECT * FROM tabla");
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>';
                    echo '<td><span id="proyectos_'.$row['id_tabla'].'">'.$row['proyectos'].'</span></td>';
                    echo '<td><span id="estadoproyecto_'.$row['id_tabla'].'">'.$row['estadoproyecto'].'</span></td>';
                    echo '<td><span id="actividades_'.$row['id_tabla'].'">'.$row['actividades'].'</span></td>';
                    echo '<td><span id="estadoactividad_'.$row['id_tabla'].'">'.$row['estadoactividad'].'</span></td>';                 echo '<td>';
    
                
                    echo '<button class="btn btn-primary" onclick="marcarFinalizadoProyecto(' . $row['id_tabla'] . ')">Finalizar Proyecto</button>';
                 
                    echo '<button class="btn btn-primary" onclick="marcarFinalizadoActividad(' . $row['id_tabla'] . ')">Finalizar Actividad</button>';
                    
                    echo '</td>';
                    echo '</tr>';
                }
                desconectar($con);
                ?>
                </tbody>
            </table>
        </div>

        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script>
function marcarFinalizadoProyecto(id) {
    var estadoproyectoSpan = document.getElementById('estadoproyecto_' + id);

 
    estadoproyectoSpan.innerText = 'Finalizado';

    $.ajax({
        type: "POST",
        url: "editar_estado.php", 
        data: { id: id, estado: 'Finalizado', tipo: 'proyecto' },  
        success: function (response) {
            console.log("Cambio de estado de proyecto guardado en la base de datos");
        },
        error: function (error) {
            console.error("Error al guardar el cambio de estado de proyecto: " + error);
        }
    });
}

function marcarFinalizadoActividad(id) {
    var estadoactividadSpan = document.getElementById('estadoactividad_' + id);
    estadoactividadSpan.innerText = 'Finalizado';

 
    $.ajax({
        type: "POST",
        url: "editar_estado.php",  
        data: { id: id, estado: 'Finalizado', tipo: 'actividad' }, 
        success: function (response) {
         
            console.log("Cambio de estado de actividad guardado en la base de datos");
        },
        error: function (error) {
            console.error("Error al guardar el cambio de estado de actividad: " + error);
        }
    });
}
</script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</body>

</html>
