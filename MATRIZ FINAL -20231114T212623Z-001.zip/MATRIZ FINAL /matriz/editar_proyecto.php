<?php
include("conexion.php");
$con = conectar();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['fechainicio'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $fechainicio = $_POST['fechainicio'];
    mysqli_query($con, "UPDATE proyectos SET proyecto = '$nombre', fecha_Inicio = '$fechainicio' WHERE id_proyecto = $id");
}
?>
