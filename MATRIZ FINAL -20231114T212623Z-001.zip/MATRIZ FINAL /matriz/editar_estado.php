<?php
include("conexion.php");
$con = conectar();

if (isset($_POST['id']) && isset($_POST['estado']) && isset($_POST['tipo'])) {
    $id = $_POST['id'];
    $estado = mysqli_real_escape_string($con, $_POST['estado']);
    $tipo = $_POST['tipo'];

    if ($tipo === 'proyecto') {
        $query = "UPDATE tabla SET estadoproyecto = '$estado',estadoactividad = '$estado' WHERE id_tabla = $id";

    } else if ($tipo === 'actividad') {
        $query = "UPDATE tabla SET estadoactividad = '$estado' WHERE id_tabla = $id";
    }

    if (mysqli_query($con, $query)) {
        echo "Cambio de estado guardado en la base de datos";
    } else {
        echo "Error al guardar el cambio de estado en la base de datos: " . mysqli_error($con);
    }

    desconectar($con);
}
?>

