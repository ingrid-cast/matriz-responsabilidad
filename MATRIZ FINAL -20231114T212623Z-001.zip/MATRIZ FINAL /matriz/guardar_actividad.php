<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="row justify-content-md-center">

    <?php
    include("conexion.php");
    $con = conectar();
    echo "Guardado con exito!";
    $actividad=$_POST['actividad'];
    mysqli_query($con,"INSERT INTO `actividades` (`actividad`) VALUES ('$actividad');");
    desconectar($con);
    ?>
    <a href="actividades.php">
        <button>VOLVER</button>
    </a>
    </div>
    </div>
</body>
</html>