<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Empleado</title>
</head>

<body>

    <div class="container">
        <form action="guardar_proyecto.php" method="POST">

            <h1>Actividades y Proyectos Asignados</h1>
            <table class="table">
                <thead>
                        <th>Proyecto</th>
                        <th>Estado Proyecto</th>
                        <th>Actividad</th>
                        <th>Estado Actividad</th>
                        <th>Observacion</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    include("conexion.php");
                    $con = conectar();
                    
                    // Obtener el nombre del empleado de la sesión
                    session_start();
                    $nombreEmpleado = $_SESSION['nombreEmpleado'];
                    echo "<p>Hola, $nombreEmpleado. ¡Bienvenido!</p>";
                    $result = mysqli_query($con, "SELECT * FROM tabla WHERE nombre = '$nombreEmpleado'");

                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<tr>';
                        echo '<td>'.$row['proyectos'].'</td>';
                        echo '<td>'.$row['estadoproyecto'].'</td>';
                        echo '<td>'.$row['actividades'].'</td>';
                        echo '<td>'.$row['estadoactividad'].'</td>';
                        echo '<td>'.$row['observacion'].'</td>';
                        echo '</tr>';
                    }

                    desconectar($con);
                    ?>
                </tbody>

            </table>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>


    <script src="script.js"></script>
</body>

</html>
