<?php
include("conexion.php");
$con = conectar();

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id_actividad'])) {
    $id_actividad = $_GET['id_actividad'];
    mysqli_query($con, "DELETE FROM actividades WHERE id_actividad = $id_actividad");
}
?>