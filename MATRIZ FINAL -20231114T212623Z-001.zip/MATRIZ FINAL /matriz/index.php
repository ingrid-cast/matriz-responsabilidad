<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link  href="form.php">
    <title>Tabla con Datos</title>
</head>
<body>
  <form action="" method="POST">
  <!--Bara de Navegacion-->
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
              <a class="navbar-brand" href="index.php">Tabla</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link" href="empleados.php">Empleados</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="proyectos.php">Proyectos</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="actividades.php">Actividades</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="estados.php">Asignacion de Estados</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        <h1>Matriz de Responsabilidades</h1>
        <div class="row justify-content-md-center">

          <!--Formulario de-->
            <form id="data-form" class=" col-sm-4">

            <label for="proyectos">Proyecto:</label>
            <select class="form-select" name="proyectos" id="proyectos">
            <option selected="Selecione una opcion">Selecione una opcion
            <?php
                include ("conexion.php");
                $con=conectar();
                $getProyectos1="SELECT * FROM proyectos ORDER BY id_proyecto";
                $getProyectos2=mysqli_query($con,$getProyectos1);
                  while($row =mysqli_fetch_array($getProyectos2))
                  {
                    $id_proyecto=$row['id_proyecto'];
                    $proyectos=$row['proyecto'];
                    $fecha_Inicio=$row['fecha_Inicio'];
                    $estadoproyecto=$row['estadoproyecto'];
                  
                  ?>
                  <option value="<?php echo $proyectos;?>"><?php echo $proyectos?> </option>
                  <?php
                  }
                  ?>
                  </option>

            </select>
           
            <label for="actividades">Actividad:</label>
            <select class="form-select" name="actividades" id="actividades">
            <option selected="Selecione una opcion">Selecione una opcion
            <?php
           
                $getActividades1="SELECT * FROM actividades ORDER BY id_actividad";
                $getActividades2=mysqli_query($con,$getActividades1);
                  while($row =mysqli_fetch_array($getActividades2))
                  {
                    $id_actividad=$row['id_actividad'];
                    $actividad=$row['actividad'];
                  
                  ?>
                  <option value="<?php echo $actividad;?>"><?php echo $actividad?> </option>
                  <?php
                  }
                  ?>
                  </option>

            </select>

            <label for="empleado">Empleado:</label>
                <select class="form-select" name="nombre" id="nombre">
                <option selected="Selecione una opcion">Selecione una opcion
                <?php
                $getEmpleados1 = "SELECT e.*
                FROM empleados e
                WHERE (
                   SELECT COUNT(t.id_tabla)
                   FROM tabla t
                   WHERE t.nombre = e.nombre
                   AND (t.estadoactividad IS NULL OR t.estadoactividad = 'Pendiente')
                ) <= 1
                ORDER BY e.id_empleado";
                $getEmpleados2=mysqli_query($con,$getEmpleados1);
                  while($row =mysqli_fetch_array($getEmpleados2))
                  {
                    $id_empleado=$row['id_empleado'];
                    $nombre=$row['nombre'];
                    $apellido=$row['apellido'];
                    $dni=$row['dni'];
                  ?>
                  <option value="<?php echo $nombre;?>"><?php echo $nombre?> </option>
                  <?php
                  }
                  ?>
               </option>
              </select>
                  
              
              <label for="Observacion">Observacion:</label>
              <input class="form-control" type="text" id="observacion" name="observacion" required>

            <button type="submit" formmethod="post" formaction="guardartabla.php" id="submit-button">Agregar a la Tabla</button>
        </form></div>
        
        <div> 
          <table id="data-table2">
            <thead>
                <tr>
                    <th>Proyecto</th>
                    <th>Actividad</th>
                    <th>Estado Actividad</th>
                    <th>Empleado</th>
                    <th>Estado Proyecto</th>
                    <th>Observacion</th>
                </tr>
            </thead>
            <tbody> 
                
                <?php
                $result = mysqli_query($con, "SELECT * FROM tabla");
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>';
                    echo '<td><span id="proyectos_'.$row['id_tabla'].'">'.$row['proyectos'].'</span></td>';
                    echo '<td><span id="actividades_'.$row['id_tabla'].'">'.$row['actividades'].'</span></td>';
                    echo '<td><span id="estadoactividad_'.$row['id_tabla'].'">'.$row['estadoactividad'].'</span></td>';
                    echo '<td><span id="nombre'.$row['id_tabla'].'">'.$row['nombre'].'</span></td>';
                    
                    echo '<td><span id="estadoproyecto'.$row['id_tabla'].'">'.$row['estadoproyecto'].'</span></td>';
                    echo '<td><span id="observacion'.$row['id_tabla'].'">'.$row['observacion'].'</span></td>';
                  
                    echo '<td>

                        <button class="btn btn-primary" onclick="editarFila('.$row['id_tabla'].')">Editar</button>
                        <button class="btn btn-danger" onclick="borrarFila('.$row['id_tabla'].')">Borrar</button>
              
                    </td>';
                    echo '</tr>';
                  
                }
                desconectar($con);
                
                ?>
              
                
                    </form>
            </tbody>
            
        </table>
        </div>
        
      </form>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>


    <script>
      function editarFila(id) {
    const row = document.querySelector(`#data-table2 #proyectos_${id}`).parentNode.parentNode;

    // Crear elementos select para editar los datos
    const proyectoSelect = document.createElement('select');
    proyectoSelect.name = 'proyectos';
    proyectoSelect.id = 'proyectos_' + id;

    const actividadSelect = document.createElement('select');
    actividadSelect.name = 'actividades';
    actividadSelect.id = 'actividades_' + id;


    const nombreSelect = document.createElement('select');
    nombreSelect.name = 'nombre';
    nombreSelect.
   

id = 'nombre' + id;
    row.
   
cells[0].innerText = '';
    row.cells[0].appendChild(proyectoSelect);

    row.

cells[2].innerText = '';
    row.cells[2].appendChild(actividadSelect);
    row.
cells[3].innerText = '';
    
    row.cells[3].appendChild(nombreSelect);
}
    
function borrarFila(id) {
                if (confirm('¿Estás seguro de que quieres borrar esta actividad?')) {
                    fetch(`borrar_tabla.php?id_tabla=${id}`)
                        .then(response => {
                            location.reload();
                        })
                        .catch(error => console.error('Error al borrar actividad:', error));
                }
            }

</script>

</form>

</body>
</html>