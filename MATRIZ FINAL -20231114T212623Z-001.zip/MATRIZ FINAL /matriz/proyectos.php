<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Tabla con Datos</title>
</head>

<body>

    <div class="container">
        <form action="guardar_proyecto.php" method="POST">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="index.php">Tabla</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarText">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link" href="empleados.php">Empleados</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="proyectos.php">Proyectos</a>
                            </li>
                            <li class="nav-item">
                                 <a class="nav-link" href="actividades.php">Actividades</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="estados.php">Asignacion de Estados</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <h1>Proyectos</h1>
            <div class="row justify-content-md-center">
                <form id="data-form" class=" col-sm-4">

                    <label for="Nombre">Nombre:</label>
                    <input class="form-control" type="text" id="nombre" name="nombre" required>


                    <label for="FechaInicio">FechaInicio:</label>
                    <input class="form-control" type="date" name="fechainicio" id="fechainicio">



                    <button type="submit" formmethod="post" formaction="guardar_proyecto.php" id="submit-button">Agregar a la Tabla</button>
                </form>
            </div>

            <div>
                <?php
                include("conexion.php");
                $con = conectar();
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $nombre = $_POST['nombre'];
                    $fechainicio = $_POST['fechainicio'];
                    $estadoproyecto = 'Pendiente';
                    mysqli_query($con, "INSERT INTO `proyectos` (`proyecto`, `fecha_Inicio`, `estadoproyecto`) VALUES ('$nombre', '$fechainicio', '$estadoproyecto');");
                }
                
                $resultado = mysqli_query($con, "SELECT * FROM proyectos");

                echo '<table id="data-table2" class="table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Fecha de Inicio</th>
                    </tr>
                </thead>
                <tbody>';

                while ($fila = mysqli_fetch_array($resultado)) {
                    echo '<tr>';
                    echo '<td><span id="nombre_'.$fila['id_proyecto'].'">'.$fila['proyecto'].'</span></td>';
                    echo '<td><span id="fechainicio_'.$fila['id_proyecto'].'">'.$fila['fecha_Inicio'].'</span></td>';
                    echo '<td>
                <button class="btn btn-primary" onclick="habilitarEdicion('.$fila['id_proyecto'].')">Editar</button>
                <button class="btn btn-danger" onclick="borrarFila('.$fila['id_proyecto'].')">Borrar</button>
                </td>';
                echo '</tr>';

                }

                echo '</tbody>
                </table>';

                desconectar($con);
                ?>
            </div>

            <script>
            function borrarFila(id_proyecto) {
                if (confirm('¿Estás seguro de que quieres borrar este proyecto?')) {
                    fetch(`borrar_proyecto.php?id_proyecto=${id_proyecto}`)
                        .then(response => {
                            location.reload();
                        })
                        .catch(error => console.error('Error al borrar el proyecto:', error));
                }
            }
            </script>
            <script>
            function habilitarEdicion(id) {
            var nombreSpan = document.getElementById('nombre_' + id);
            var fechainicioSpan = document.getElementById('fechainicio_' + id);

            var nombreValor = nombreSpan.innerText;
            var fechainicioValor = fechainicioSpan.innerText;

            nombreSpan.innerHTML = '<input type="text" value="' + nombreValor + '" id="nombre_input_' + id + '">';
            fechainicioSpan.innerHTML = '<input type="date" value="' + fechainicioValor + '" id="fechainicio_input_' + id + '">';

            var editarButton = document.querySelector('button[onclick="habilitarEdicion(' + id + ')"]');
            editarButton.setAttribute('onclick', 'editarFila(' + id + ')');
            editarButton.innerText = 'Guardar';
        }

            function editarFila(id) {
            var nombre = document.getElementById('nombre_input_' + id).value;
            var fechainicio = document.getElementById('fechainicio_input_' + id).value;

            var data = new URLSearchParams();
            data.append('id', id);
            data.append('nombre', nombre);
            data.append('fechainicio', fechainicio);

            fetch('editar_proyecto.php', {
            method: 'POST',
            body: data
            })
            .then(response => {
            location.reload();
            })
            .catch(error => console.error('Error al editar el proyecto:', error));
        }
    </script>


        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <script src="script.js"></script>
</body>

</html>
