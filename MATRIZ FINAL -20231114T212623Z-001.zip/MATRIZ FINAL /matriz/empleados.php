<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Tabla con Datos</title>
</head>
<body>
  <form action="guardar_empleados.php" method="POST">
  <!--Bara de Navegacion-->
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
              <a class="navbar-brand" href="index.php">Tabla</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link" href="empleados.php">Empleados</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="proyectos.php">Proyectos</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="actividades.php">Actividades</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="estados.php">Asignacion de Estados</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        <h1>Empleados</h1>
        <div class="row justify-content-md-center">

          <!--Formulario de-->
            <form id="data-form" class=" col-sm-4">

            <label for="Nombre">Nombre:</label>
            <input class="form-control" type="text" id="nombre" name="nombre" required>
          
            <label for="Apellido">Apellido:</label>
            <input class="form-control" type="text" id="apellido" name="apellido" required>

            <label for="DNI">Dni:</label>
            <input class="form-control" type="number" name="dni" id="dni">


            <button type="submit" formmethod="post" formaction="guardar_empleados.php" id="submit-button">Agregar a la Tabla</button>
        </form></div>
        
        <div> 
          <table id="data-table2">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Dni</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("conexion.php");
                $con = conectar();
                $result = mysqli_query($con, "SELECT * FROM empleados");
                while ($row = mysqli_fetch_assoc($result)) {
                  echo '<tr>';
                  echo '<td><span id="nombre_'.$row['id_empleado'].'">'.$row['nombre'].'</span></td>';
                  echo '<td><span id="apellido_'.$row['id_empleado'].'">'.$row['apellido'].'</span></td>';
                  echo '<td><span id="dni_'.$row['id_empleado'].'">'.$row['dni'].'</span></td>';
                  echo '<td>
                          <button class="btn btn-primary" onclick="habilitarEdicion('.$row['id_empleado'].')">Editar</button>
                          <button class="btn btn-danger" onclick="borrarFila('.$row['id_empleado'].')">Borrar</button>
                      </td>';
                  echo '</tr>';
                  
                }
                desconectar($con);
                ?>
            </tbody>
        </table>
        </div>
        
      </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <script>
    function habilitarEdicion(id) {
        var nombreSpan = document.getElementById('nombre_' + id);
        var apellidoSpan = document.getElementById('apellido_' + id);
        var dniSpan = document.getElementById('dni_' + id);

        var nombreValor = nombreSpan.innerText;
        var apellidoValor = apellidoSpan.innerText;
        var dniValor = dniSpan.innerText;

        nombreSpan.innerHTML = '<input type="text" value="' + nombreValor + '" id="nombre_input_' + id + '">';
        apellidoSpan.innerHTML = '<input type="text" value="' + apellidoValor + '" id="apellido_input_' + id + '">';
        dniSpan.innerHTML = '<input type="number" value="' + dniValor + '" id="dni_input_' + id + '">';
       

        var editarButton = document.querySelector('button[onclick="habilitarEdicion(' + id + ')"]');
        editarButton.setAttribute('onclick', 'guardarEdicion(' + id + ')');
        editarButton.innerText = 'Guardar';
    }

    function guardarEdicion(id) {
        var nombre = document.getElementById('nombre_input_' + id).value;
        var apellido = document.getElementById('apellido_input_' + id).value;
        var dni = document.getElementById('dni_input_' + id).value;

        var data = new URLSearchParams();
        data.append('id', id);
        data.append('nombre', nombre);
        data.append('apellido', apellido);
        data.append('dni', dni);

        fetch('editar_empleado.php', {
            method: 'POST',
            body: data
        })
        .then(response => {
            location.reload();
        })
        .catch(error => console.error('Error al editar el empleado:', error));
    }

    function borrarFila(id) {
        if (confirm('¿Estás seguro de que quieres borrar este empleado?')) {
            fetch(`borrar_empleado.php?id=${id}`)
                .then(response => {
                    location.reload();
                })
                .catch(error => console.error('Error al borrar el empleado:', error));
        }
    }
</script>

    <script src="script.js"></script>
</body>
</html>