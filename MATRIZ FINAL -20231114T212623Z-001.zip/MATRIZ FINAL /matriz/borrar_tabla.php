
<?php
include("conexion.php");
$con = conectar();

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id_tabla'])) {
    $id_tabla = $_GET['id_tabla'];
    mysqli_query($con, "DELETE  FROM `tabla` WHERE `id_tabla`=$id_tabla");
}
?>