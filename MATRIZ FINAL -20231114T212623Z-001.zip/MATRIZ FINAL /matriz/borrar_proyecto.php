<?php
include("conexion.php");
$con = conectar();

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id_proyecto'])) {
    $id_proyecto = $_GET['id_proyecto'];
    mysqli_query($con, "DELETE FROM proyectos WHERE id_proyecto = $id_proyecto");
}
?>
