<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="row justify-content-md-center">

    <?php
    include("conexion.php");
    $con = conectar();
    if (isset($_POST['id']) && isset($_POST['estado']) && isset($_POST['tipo'])) { 
   
    $proyectos=$_POST['proyectos'];
    $actividades=$_POST['actividades'];
    $nombre=$_POST['nombre'];

    mysqli_query($con, "UPDATE `tabla` SET `proyectos`='$proyectos',`actividades`='$actividades',`nombre`=''$nombre'' WHERE id_tabla = $id ;");
    desconectar($con);
    }
    ?>
    <a href="index.php">
        <button>VOLVER</button>
    </a>
    </div>
    </div>
</body>
</html>