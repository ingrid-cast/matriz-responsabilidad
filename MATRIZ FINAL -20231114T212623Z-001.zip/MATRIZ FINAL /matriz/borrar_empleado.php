<?php
include("conexion.php");
$con = conectar();

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];
    mysqli_query($con, "DELETE FROM empleados WHERE id_empleado = $id");
}
?>